﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace ThreadJoinUI
{
    public partial class Form1 : Form
    {
        Thread t1, t2;
        Random rand = new Random();
        int a, b;
        public delegate void DelegateInsertList(ListBox  list, string text);
        public delegate void DelegateSetLabelText(Label label, string text);
        public Form1()
        {
            InitializeComponent();
        }

        private void btStart_Click(object sender, EventArgs e)
        {
            t1 = new Thread(A);                
            t1.Start();
            
            
        }
        public void A()
        {
            t2 = new Thread(B);
            t2.Start();
            t1.Abort();
            while (a < 50)
            {
                InsertList(listNumber, "Thread 1: " + rand.Next(501, 1001).ToString());
                SetLabelText(lbCount, "Số phần tử: " + listNumber.Items.Count.ToString());
                Thread.Sleep(300);
                a++;
            }
        }
        public void B()
        {
            while (b < 50)
            {
                InsertList(listNumber,"Thread 2: "+ rand.Next(1, 501).ToString());
                SetLabelText(lbCount,"Số phần tử: "+ listNumber.Items.Count.ToString());
                Thread.Sleep(300);
                b++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            a = b = 0;
            
        }
        private void InsertList(ListBox  list, string text)
        {
            if (list.InvokeRequired)
            {
                DelegateInsertList d = new DelegateInsertList(InsertList);
                this.Invoke(d, new object[] { list, text });
            }
            else
            {
                list.Items.Add(text);
                list.SelectedItem=text ;
            }

        }

        private void btClear_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void SetLabelText(Label label, string text)
        {
            if (label.InvokeRequired)
            {
                DelegateSetLabelText d = new DelegateSetLabelText(SetLabelText);
                this.Invoke(d, new object[] { label, text });
            }
            else
            {
                label.Text = text;
            }

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Đóng?", "Chú ý!", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.No)
                e.Cancel = true;
        }
    }
}
