﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace ThreadJoinUI
{
    #region MaiTrang
    //Đa luồng, sử dụng Monitor
    #endregion
    public partial class Form1 : Form
    {
        object obj = new object();
        Thread t1, t2;
        Random rand = new Random();
    
        public delegate void DelegateInsertList(ListBox  list, string text);
        public delegate void DelegateSetLabelText(Label label, string text);
        public Form1()
        {
            InitializeComponent();
        }

        private void btStart_Click(object sender, EventArgs e)
        {
            t1 = new Thread(A);                
            t1.Start();
            t2 = new Thread(B);
            t2.Start();
        }
        public void A()
        {
            while (true)
            {
                Monitor.Enter(obj);
                InsertList(listNumber, "Thread 1: " + rand.Next(501, 1001).ToString());
                Monitor.Exit(obj);
                SetLabelText(lbCount, "Số phần tử: " + listNumber.Items.Count.ToString());
                Thread.Sleep(300);
            }
            
        }
        public void B()
        {
            while (true)
            {
                Monitor.Enter(obj);
                InsertList(listNumber,"Thread 2: "+ rand.Next(1, 501).ToString());
                Monitor.Exit(obj);
                SetLabelText(lbCount,"Số phần tử: "+ listNumber.Items.Count.ToString());
                Thread.Sleep(300);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
            
        }
        private void InsertList(ListBox  list, string text)
        {
            if (list.InvokeRequired)
            {
                DelegateInsertList d = new DelegateInsertList(InsertList);
                this.Invoke(d, new object[] { list, text });
            }
            else
            {
                list.Items.Add(text);
                list.SelectedItem=text ;
            }

        }

        private void btClear_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btStop_Click(object sender, EventArgs e)
        {
            t1.Abort();
            t2.Abort();
        }

        private void SetLabelText(Label label, string text)
        {
            if (label.InvokeRequired)
            {
                DelegateSetLabelText d = new DelegateSetLabelText(SetLabelText);
                this.Invoke(d, new object[] { label, text });
            }
            else
            {
                label.Text = text;
            }

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Đóng?", "Chú ý!", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.No)
                e.Cancel = true;
            t1.Abort();
            t2.Abort();
        }
    }
}
